# Seminario de capacitación en el uso del paquete gfwr para obtener acceso a los datos de Global Fishing Watch

30 de Abril de 2025

Andrea Sánchez-Tapia  
Rocío Joo

## Estructura de este repositorio

```
.
├── 1_configuracion_instalacion.R
├── 2_breve_intro_a_R.R
├── 3_get_vessel_info.R
├── 4_get_event.R
├── 5_get_raster.R
├── 6_haciendo_mapas.R
├── data
└── gfwr_espanhol.Rproj
```

Por favor, descargue el repositorio en formato zip (última opción del menú del botón verde arriba, a la derecha)

![image](https://github.com/user-attachments/assets/c971dca9-f416-410c-942b-4b0c07a40ee9)


Guárdelo en su computadora y extraiga el ZIP. Haga click en el archivo `gfwr_espanhol.Rproj` para abrir el projecto en RStudio. 
